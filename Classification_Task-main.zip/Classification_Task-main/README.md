# Classification_Task
Classification Task using [Resnet18 model]
